# setup.py
import setuptools

setuptools.setup(
    name="porty",
    version="0.0.1",
    author="0x1911",
    author_email="username@example.com",
    description="Practical Python Code",
    packages=setuptools.find_packages(),
)
